#include "Lib.h"
#include "globalVars.h"

void main() {
    int numData[250];
    populateArray(numData);

    int i = 0;
    findMax(numData);
}