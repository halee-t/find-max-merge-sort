//global declaration of numData

extern int numData[];