//declaration for populateArray and findMax functions

extern void populateArray(int numData[]);
extern void findMax(int numData[]);